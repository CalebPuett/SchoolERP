<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Search All</title>
<!-- BOOTSTRAP STYLES-->
<link href="assets/css/bootstrap.css" rel="stylesheet" />
<!-- FONTAWESOME STYLES-->
<link href="assets/css/font-awesome.css" rel="stylesheet" />
   <!--CUSTOM BASIC STYLES-->
<link href="assets/css/basic.css" rel="stylesheet" />
<!--CUSTOM MAIN STYLES-->
<link href="assets/css/custom.css" rel="stylesheet" />
<!--[if lt IE 9]><script src="scripts/flashcanvas.js"></script><![endif]-->
<!-- JQUERY SCRIPTS -->
<script src="assets/js/jquery-1.10.2.js"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="assets/js/bootstrap.js"></script>


<style>
    .default {background-color:#E1E1E1;}
</style>
<script>
    function addFocus(div){
        document.getElementById(div).classList.remove("default");
    }
    function removeFocus(div){
        document.getElementById(div).classList.add("default");
    }
</script>
</head>
<body>
<?php
include ("functions.php");
$dblink = db_connect("docstorage");
echo '<div id="page-inner">';
echo '<h1 class="page-head-line">All Loans</h1>';
echo '<div class="panel-body">';
echo "<h2>All Loans</h2>";
		echo '<table>';
		//$loan = $result->fetch_array(MYSQLI_ASSOC);
		echo '<th>File Name</th><th>File Type </th><th>&nbsp Upload Date </th><th>&nbsp Action </th>';
		$sql = "Select * From `Documents` where `loan_id` != ''";
		$results = $dblink->query($sql) or
			die("Something went wrong with: $sql<br>".$dblink->error);
		while($data = $results->fetch_array(MYSQLI_ASSOC)){
			if($data['ID'] >= 15){ // due to content table not being on the same id as docs table
				echo "<tr>";
				echo '<td>'.$data['file_name'].'</td>';
				echo '<td>'.$data['file_type'].'</td>';
				$tmp = explode("-",$data['file_name']);
				$tmp1 = explode(".",$tmp[2]);
				$tmp2 = explode("_",$tmp1[0]);
				echo '<td>&nbsp'.$tmp2[0].'</td>';

					echo '<td><a href="https://ec2-18-188-192-136.us-east-2.compute.amazonaws.com/view_file.php?fid='.$data['ID'].'" target="_blank">View File</a></td>';
				}
			echo '</tr>';
		}
		echo '</table>';