<?php
function db_connect($db){  // this needs to be fixed go watch the database vid for the function
	$hostname="localhost";
	$username="webuser";
	$password="BitTAH66wnThI1g2";
	$dblink = new mysqli($hostname,$username,$password,$db);
	if(mysqli_connect_errno()){
		die("Error connecting to database: ".mysqli_connect_error());
	}
	return($dblink);
	
}
function Create(){
	$username = 'nuu544';
	$password = 'GLWVXhT3yM4cpY2!';
	$data = "username=$username&password=$password";
	$ch = curl_init('https://cs4743.professorvaladez.com/api/create_session');
	curl_setopt($ch, CURLOPT_POST,1);
	curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_HTTPHEADER,array(
			'content-type: application/x-www-form-urlencoded',
			'content-length: '. strlen($data))
				);
	$time_start = microtime(true);
	$result = curl_exec($ch);
	$time_end = microtime(true);
	$execution_time = ($time_end - $time_start)/60;
	curl_close($ch);
	$cinfo = json_decode($result,true);
	return ($cinfo);
}
function Close($data){
	$ch = curl_init('https://cs4743.professorvaladez.com/api/close_session');
		curl_setopt($ch, CURLOPT_POST,1);
		curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER,array(
				'content-type: application/x-www-form-urlencoded',
				'content-length: '. strlen($data))
				);
	$time_start = microtime(true);
	$result = curl_exec($ch);
	$time_end = microtime(true);
	$execution_time = ($time_end - $time_start)/60;
	curl_close($ch);
	$cinfo = json_decode($result,true);
	return($cinfo);
}
function clearSession(){
	$username = 'nuu544';
	$password = 'GLWVXhT3yM4cpY2!';
	$data = "username=$username&password=$password";
	$ch = curl_init('https://cs4743.professorvaladez.com/api/clear_session');
	curl_setopt($ch, CURLOPT_POST,1);
	curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_HTTPHEADER,array(
			'content-type: application/x-www-form-urlencoded',
			'content-length: '. strlen($data))
				);
	$time_start = microtime(true);
	$result = curl_exec($ch);
	$time_end = microtime(true);
	$execution_time = ($time_end - $time_start)/60;
	curl_close($ch);
	$cinfo = json_decode($result,true);
	
}
function qureyFiles($data){
	$ch = curl_init('https://cs4743.professorvaladez.com/api/query_files');
	curl_setopt($ch, CURLOPT_POST,1);
	curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_HTTPHEADER,array(
		'content-type: application/x-www-form-urlencoded',
		'content-length: '. strlen($data))
			);
	$time_start = microtime(true);
	$result = curl_exec($ch);
	$time_end = microtime(true);
	$execution_time = ($time_end - $time_start)/60;
	echo ("query: $execution_time");
	curl_close($ch);
	return $result;
}
function retry($data){
	sleep(300);
	$results = queryFiles($data);
	return $results;
}
function requestFiles($data,$file,$dblink){
			$fileData=explode("-",$file);
			$ch = curl_init('https://cs4743.professorvaladez.com/api/request_file');
			curl_setopt($ch, CURLOPT_POST,1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_HTTPHEADER,array(
				'content-type: application/x-www-form-urlencoded',
				'content-length: '. strlen($data))
				);
			//$time_start = microtime(true);
	
			$result = curl_exec($ch);
			//$time_end = microtime(true);
			//$execution_time = ($time_end - $time_start)/60;
			curl_close($ch);
			$contentClean=addslashes($result);
			$dateStamp = explode(".pdf",$fileData[2]);
			$sql = "Insert into `Documents`
			(`loan_id`,`file_name`,`file_type`,`date`) VALUES
			('$fileData[0]','$file','$fileData[1]','$dateStamp[0]')";
			$dblink->query($sql) or
				die("<h3> Something went wrong with: $sql<br>".$dblink->error);

			$linkId = mysqli_insert_id($dblink);
			$sql = "Insert into `Document_Content`
			(`file_id`,`file_content`) VALUES
			('$linkId','$contentClean')";
			$dblink->query($sql) or
				die("<h3> Something went wrong with: $sql<br>".$dblink->error);
			echo "<h3>File: $file written to Database";

}
function redirect($uri){
	?>
		<script type ="text/javascript">
		<!--
		document.location.href="<?php echo $uri; ?>";
		-->
		</script>
<?php die;
		
}



function getLoanTotalDoc($loanNum,$dblink){
	$sql = "Select Count(`file_name`) from `Documents` where `loan_Id` = $loanNum";
	$results = $dblink->query($sql) or
		die("<h3> Something went wrong with: $sql<br>".$dblink->error);
	$data = $results->fetch_array(MYSQLI_ASSOC);
	return $data['Count(`file_name`)'];
}
function getAverageSizeForLoanID($loanNum,$dblink){
	$sql = "SELECT Avg(length) as averageSize\n"

    . "FROM(\n"

    . "    Select `file_Size` as length\n"

    . "    from `Documents`\n"

    . "    join `Doc_Size`\n"

    . "    on Doc_Size.`file_id` = Documents.ID\n"

    . "    where Documents.loan_Id = $loanNum\n"

    . "    )as test;";
	$results = $dblink->query($sql) or
		die("<h3> Something went wrong with: $sql<br>".$dblink->error);
	$data = $results->fetch_array(MYSQLI_ASSOC);
	return $data['averageSize'];
	
}
?>