<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Upload Main</title>
<!-- BOOTSTRAP STYLES-->
<link href="assets/css/bootstrap.css" rel="stylesheet" />
<!-- FONTAWESOME STYLES-->
<link href="assets/css/font-awesome.css" rel="stylesheet" />
   <!--CUSTOM BASIC STYLES-->
<link href="assets/css/basic.css" rel="stylesheet" />
<!--CUSTOM MAIN STYLES-->
<link href="assets/css/custom.css" rel="stylesheet" />
<!-- PAGE LEVEL STYLES -->
<link href="assets/css/bootstrap-fileupload.min.css" rel="stylesheet" />
<!-- PAGE LEVEL STYLES -->
<link href="assets/css/prettyPhoto.css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="assets/css/print.css" media="print" />
<!--[if lt IE 9]><script src="scripts/flashcanvas.js"></script><![endif]-->
<!-- JQUERY SCRIPTS -->
<script src="assets/js/jquery-1.10.2.js"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="assets/js/bootstrap.js"></script>
<!-- METISMENU SCRIPTS -->
<script src="assets/js/jquery.metisMenu.js"></script>
   <!-- CUSTOM SCRIPTS <script src="assets/js/custom.js"></script>-->
<script src="assets/js/bootstrap-fileupload.js"></script>

<script src="assets/js/jquery.prettyPhoto.js"></script>
<script src="assets/js/galleryCustom.js"></script>
</head>
<body>
<?php
include("functions.php");
date_default_timezone_set("America/Chicago");
$date = date(DATE_RFC2822);
$dblink = db_connect("docstorage");
echo '<div id="page-inner">';
echo '<h1 class="page-head-line">Upload a New File to DocStorage</h1>';
echo '<div class="panel-body">';
if(isset($_REQUEST['msg']) && ($_REQUEST['msg'] == "invalidFileType")){
	echo '<div class="alert alert-warning alert-dismissable">';
	echo '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>';
	echo 'File must be pdf. Please try again</div>';
}
echo '<form method="post" enctype="multipart/form-data" action="">';
echo '<input type="hidden" name="MAX_FILE_SIZE" value="10000000">';
echo '<div class="form-group">';
echo '<label for="loanNum" class="control-label">Loan Number</label>';
echo '<select class="form-control" name="loanNum">';
$sql = "SELECT DISTINCT `loan_Id` FROM `Documents`";
$results = $dblink->query($sql) or
	die("Something went wrong with: $sql<br>".$dblink->error);
while($data=$results->fetch_array(MYSQLI_ASSOC)){
	echo '<option value="'.$data['loan_Id'].'">'.$data['loan_Id'].'</option>';
}
echo '</select>';
echo '</div>';
echo '<div class="form-group">';
echo '<label for="docType" class="control-label">Document Type</label>';
echo '<select class="form-control" name="docType">';
$sql = "SELECT DISTINCT `file_type` FROM `Documents` Where `file_type` != ''";
$results = $dblink->query($sql) or
	die("Something went wrong with: $sql<br>".$dblink->error);
while($data=$results->fetch_array(MYSQLI_ASSOC)){
	echo '<option value="'.$data['file_type'].'">'.$data['file_type'].'</option>';
}
echo '</select>';
echo '</div>';
echo '<div class="form-group">';
echo '<label class="control-label col-lg-4">File Upload</label>';
echo '<div class="">';
echo '<div class="fileupload fileupload-new" data-provides="fileupload">';
echo '<div class="fileupload-preview thumbnail" style="width: 200px; height: 150px;"></div>';
echo '<div class="row">';
echo '<div class="col-md-2">';
echo '<span class="btn btn-file btn-primary">';
echo '<span class="fileupload-new">Select File</span>';
echo '<span class="fileupload-exists">Change</span>';
echo '<input name="userfile" type="file"></span></div>';
echo '<div class="col-md-2"><a href="#" class="btn btn-danger fileupload-exists" data-dismiss="fileupload">Remove</a></div>';
echo '</div></div></div></div><hr>';
echo '<button type="submit" name="submit" value="submit" class="btn btn-lg btn-block btn-success">Upload File</button>';
echo '</form>';
echo '</div>';
echo '</div>';
if(isset($_POST['submit'])){
	$time_start = microtime(true); 
	$dblink = db_connect("docstorage");
	$uploadDname = date("Ymd_H_i_s");
	$loanNum = $_POST['loanNum'];
	$docType = $_POST['docType'];
	$tmpName = $_FILES['userfile']['tmp_name'];
	$fileType = $_FILES['userfile']['type'];
	if($fileType != 'application/pdf' ){
		redirect("https://ec2-18-188-192-136.us-east-2.compute.amazonaws.com/upload_existing.php?msg=invalidFileType");
		$time_end = microtime(true);
		$execution_time = ($time_end - $time_start)/60;
	}
	else{
	$fp = fopen($tmpName,'r');
	$content = fread($fp, filesize($tmpName));
	fclose($fp);
	$contentClean = addslashes($content);
	$fileName = "$loanNum-$docType-$uploadDname.pdf";
	$sql = "Insert into `Documents`
			(`loan_id`,`file_name`,`file_type`,`date`) VALUES
			('$loanNum','$fileName','$docType','$uploadDname')";
	$dblink->query($sql) or
		die("Something went wrong with: $sql<br>".$dblink->error);
	$linkId = mysqli_insert_id($dblink);
	$sql = "Insert into `Document_Content`
			(`file_id`,`file_content`) VALUES
			('$linkId','$contentClean')";
			$dblink->query($sql) or
				die("<h3> Something went wrong with: $sql<br>".$dblink->error);
	$time_end = microtime(true);
	$execution_time = ($time_end - $time_start)/60;
	$sql = "Insert into `Logs`
			(`type`,`ExecutionTime`,`Message`,`date`) VALUES
			('User Upload','$execution_time','Existing File Uploaded','$date')";
		$dblink->query($sql) or
				die("<h3> Something went wrong with: $sql<br>".$dblink->error);
	redirect("https://ec2-18-188-192-136.us-east-2.compute.amazonaws.com/upload_main.php?msg=success");
	}
}
?>
</body>
</html>