<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Search Main</title>
<!-- BOOTSTRAP STYLES-->
<link href="assets/css/bootstrap.css" rel="stylesheet" />
<!-- FONTAWESOME STYLES-->
<link href="assets/css/font-awesome.css" rel="stylesheet" />
   <!--CUSTOM BASIC STYLES-->
<link href="assets/css/basic.css" rel="stylesheet" />
<!--CUSTOM MAIN STYLES-->
<link href="assets/css/custom.css" rel="stylesheet" />
<!--[if lt IE 9]><script src="scripts/flashcanvas.js"></script><![endif]-->
<!-- JQUERY SCRIPTS -->
<script src="assets/js/jquery-1.10.2.js"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="assets/js/bootstrap.js"></script>


<style>
    .default {background-color:#E1E1E1;}
</style>
<script>
    function addFocus(div){
        document.getElementById(div).classList.remove("default");
    }
    function removeFocus(div){
        document.getElementById(div).classList.add("default");
    }
</script>
</head>
<body>
<?php
echo '<div id="page-inner">';
echo '<h1 class="page-head-line">Select the Search criteria</h1>';
echo '<div class="panel-body">';
echo '<div id="1" class="alert alert-info default text-center" onmouseover="addFocus(this.id)" onmouseout="removeFocus(this.id)"><i class="fa fa-plus-circle fa-5x"></i><h3>Search by loan number</h3>';
echo '<a href="search_loanNumber.php" class="btn btn-default">Search by loan number</a></div>';
echo '<div id="2" class="alert alert-info default text-center" onmouseover="addFocus(this.id)" onmouseout="removeFocus(this.id)"><i class="fa fa-file-o fa-5x"></i><h3>Search by file type</h3><a href="search_fileType.php" class="btn btn-default">Search by file type</a></div>';
echo '<div id="3" class="alert alert-info default text-center" onmouseover="addFocus(this.id)" onmouseout="removeFocus(this.id)"><i class="fa fa-plus-circle fa-5x"></i><h3>Search by File Date</h3>';
echo '<a href="search_Date.php" class="btn btn-default">Search by File Date</a></div>';
echo '<div id="4" class="alert alert-info default text-center" onmouseover="addFocus(this.id)" onmouseout="removeFocus(this.id)"><i class="fa fa-plus-circle fa-5x"></i><h3>List All Files</h3>';
echo '<a href="search_All.php" class="btn btn-default">List All Files</a></div>';
echo '</div></div></div></body>
</html>';
?>


