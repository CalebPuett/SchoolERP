<?php
ini_set("display_errors",1);
ini_set("display_startup_errors",1);
error_reporting(E_ALL);
date_default_timezone_set("America/Chicago");
include("functions.php");
$dblink = db_connect("docstorage");
$clear = "ClearSession";
$create = "Create";
$error = "Error";
$clearMess = "Session Cleared";
$createMess = "Session Created";
$queryMess = "Sucessfull query";
$close = "close";
$closeMess = "Session Closed";
$errorMess = "A error has occured";
$qur = "Query";
$username = 'nuu544';
$password = 'GLWVXhT3yM4cpY2!';
$data = "username=$username&password=$password";
$time_start = microtime(true); 
$cinfo = Create();

$date = date(DATE_RFC2822);
$time_end = microtime(true);
$execution_time = ($time_end - $time_start)/60;
if($cinfo == null){
	$sql = "Insert into `Logs`
			(`type`,`ExecutionTime`,`Message`,`date`) VALUES
			('Error','$execution_time','Error connecting to Server','$date')";
$dblink->query($sql) or
		die("<h3> Something went wrong with: $sql<br>".$dblink->error);
	exit();
	
}
$sql = "Insert into `Logs`
			(`type`,`ExecutionTime`,`Message`,`date`) VALUES
			('$create','$execution_time','$createMess','$date')";
$dblink->query($sql) or
		die("<h3> Something went wrong with: $sql<br>".$dblink->error);
if($cinfo[0] == "Status: ERROR" && $cinfo[1] == "MSG: Previous Session Found"){
	$time_start = microtime(true); 
	clearSession();
	$time_end = microtime(true);
	$execution_time = ($time_end - $time_start)/60;
	$sql = "Insert into `Logs`
			(`type`,`ExecutionTime`,`Message`,`date`) VALUES
			('$clear','$execution_time','$clearMess','$date')";
	$dblink->query($sql) or
				die("<h3> Something went wrong with: $sql<br>".$dblink->error);
	$time_start = microtime(true); 
	$cinfo = Create();
	$time_end = microtime(true);
	$execution_time = ($time_end - $time_start)/60;
	$sql = "Insert into `Logs`
			(`type`,`ExecutionTime`,`Message`,`date`) VALUES
			('$create','$execution_time','$createMess','$date')";
	$dblink->query($sql) or
				die("<h3> Something went wrong with: $sql<br>".$dblink->error);
}

if($cinfo[0] == "Status: OK" && $cinfo[1] == "MSG: Session Created"){
	$sid = $cinfo[2];
	$data = "uid=$username&sid=$sid";
	$time_start = microtime(true); 
	$queryResult = qureyFiles($data);
	$time_end = microtime(true);
	$execution_time = ($time_end - $time_start)/60;
	if($queryResult != null){
		$sql = "Insert into `Logs`
			(`type`,`ExecutionTime`,`Message`,`date`) VALUES
			('$qur','$execution_time','$queryMess','$date')";
		$dblink->query($sql) or
				die("<h3> Something went wrong with: $sql<br>".$dblink->error);
	}
	else{
		$sql = "Insert into `Logs`
			(`type`,`ExecutionTime`,`Message`,`date`) VALUES
			('$error','$execution_time','$errorMess','$date')";
		$dblink->query($sql) or
				die("<h3> Something went wrong with: $sql<br>".$dblink->error);
	}
	$tmp = json_decode($queryResult,true);
	$tmp2 = explode(":",$tmp[1]);
	$files = json_decode($tmp2[1]);
	foreach($files as $key=>$value){
			$tmp3 = explode("/",$value);
			$currentFile = $tmp3[4];
			$fileData=explode("-",$currentFile);
			$data = "uid=$username&sid=$sid&fid=$currentFile";
			$ch = curl_init('https://cs4743.professorvaladez.com/api/request_file');
			curl_setopt($ch, CURLOPT_POST,1);
			curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_HTTPHEADER,array(
				'content-type: application/x-www-form-urlencoded',
				'content-length: '. strlen($data))
				);
			//$time_start = microtime(true);
			$result = curl_exec($ch);
			//$time_end = microtime(true);
			//$execution_time = ($time_end - $time_start)/60;
			curl_close($ch);
			$contentClean=addslashes($result);
			//$test = strlen($contentClean);
			//echo "<pre>";
			//print_r($test);
			//echo "</pre>";
			$dateStamp = explode(".pdf",$fileData[2]);
			$sql = "Insert into `Documents`
			(`loan_id`,`file_name`,`file_type`,`date`) VALUES
			('$fileData[0]','$currentFile','$fileData[1]','$dateStamp[0]')";
			$dblink->query($sql) or
				die("<h3> Something went wrong with: $sql<br>".$dblink->error);

			$linkId = mysqli_insert_id($dblink);
			$sql = "Insert into `Document_Content`
			(`file_id`,`file_content`) VALUES
			('$linkId','$contentClean')";
			$dblink->query($sql) or
				die("<h3> Something went wrong with: $sql<br>".$dblink->error);
			echo "<h3>File: $currentFile written to Database";

		}
	
		$data="sid=$sid&uid=$username";
		$time_start = microtime(true); 	
		$cinfo = Close($data);
		$time_end = microtime(true);
		$execution_time = ($time_end - $time_start)/60;
		if($cinfo[0] == "Status: OK"){
			$sql = "Insert into `Logs`
			(`type`,`ExecutionTime`,`Message`,`date`) VALUES
			('$close','$execution_time','$closeMess','$date')";
		$dblink->query($sql) or
				die("<h3> Something went wrong with: $sql<br>".$dblink->error);
		}
}
			
	
else{
	echo "<pre>";
	echo print_r($cinfo);
	echo "</pre>";
}

?>