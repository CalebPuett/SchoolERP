<?php
ini_set("display_errors",1);
ini_set("display_startup_errors",1);
error_reporting(E_ALL);
date_default_timezone_set("America/Chicago");
include("functions.php");
$dblink = db_connect("docstorage");
$cinfo = Create();
$username = 'nuu544';
$password = 'GLWVXhT3yM4cpY2!';
$date = date(DATE_RFC2822);
$data = "username=$username&password=$password";
if($cinfo[0] == "Status: ERROR" && $cinfo[1] == "MSG: Previous Session Found"){
	clearSession();
	$cinfo = Create();
}
if($cinfo[0] == "Status: OK" && $cinfo[1] == "MSG: Session Created"){
	$sid = $cinfo[2];
	$data = "uid=$username&sid=$sid";
	$ch = curl_init('https://cs4743.professorvaladez.com/api/request_all_documents');
	curl_setopt($ch, CURLOPT_POST,1);
	curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_HTTPHEADER,array(
		'content-type: application/x-www-form-urlencoded',
		'content-length: '. strlen($data))
			   );
	$result = curl_exec($ch);
	//$time_end = microtime(true);
	//$execution_time = ($time_end - $time_start)/60;
	curl_close($ch);
	$tmp = json_decode($result,true);
	$files = explode(":",$tmp[1]);
	$tmp2 = explode("[",$files[1]);
	$tmp3 = explode(",",$tmp2[1]);
	$numMissing = 0;
	foreach($tmp3 as $key=>$value){
		$tmp = trim($value,']');
		$file = trim($tmp,'"');
		$sql = "Select Exists(Select * From `Documents` Where `file_name` = '$file')";
		$quer = $dblink->query($sql) or
			die("<h3> Something went wrong with: $sql<br>".$dblink->error);
		$row = mysqli_fetch_array($quer);
		$data = "uid=$username&sid=$sid&fid=$file";
		if($row[0] == 0){
			echo "<pre>";
			print_r($row[0]);
			echo "</pre>";
			$time_start = microtime(true);
			requestFiles($data,$file,$dblink);
			$time_end = microtime(true);
			$execution_time = ($time_end - $time_start)/60;
			$sql = "Insert into `Logs`
				(`type`,`ExecutionTime`,`Message`,`date`) VALUES
				('Request','$execution_time','requesting all unadded files','$date')";
			$dblink->query($sql) or
				die("<h3> Something went wrong with: $sql<br>".$dblink->error);
			$numMissing++;
			echo "<h3>File: $file added to database</h3>";
		}
	}
	echo "<h3>Added $numMissing files</h3>";
		
}	
	$cinfo = Close($data);
