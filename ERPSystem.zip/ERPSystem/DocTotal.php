<?php
include("functions.php");
$dblink = db_connect("docstorage");
echo "<h3> Amount of Documents for Each Document Type</h3>";

$sql = "Select Count(`file_name`) from `Documents` where `file_type` = 'Credit' and `ID` between 94 and 2703 and `loan_Id` != ''";
$results = $dblink->query($sql) or
		die("<h3> Something went wrong with: $sql<br>".$dblink->error);
$data = $results->fetch_array(MYSQLI_ASSOC);
echo 'Credit:'.$data['Count(`file_name`)'];
echo '<br>';

$sql = "Select Count(`file_name`) from `Documents` where `file_type` = 'Closing' and `ID` between 94 and 2703 and `loan_Id` != ''";
$results = $dblink->query($sql) or
		die("<h3> Something went wrong with: $sql<br>".$dblink->error);
$data = $results->fetch_array(MYSQLI_ASSOC);
echo 'Closing:'.$data['Count(`file_name`)'];
echo '<br>';

$sql = "Select Count(`file_name`) from `Documents` where `file_type` = 'Title' and `ID` between 94 and 2703 and `loan_Id` != ''";
$results = $dblink->query($sql) or
		die("<h3> Something went wrong with: $sql<br>".$dblink->error);
$data = $results->fetch_array(MYSQLI_ASSOC);
echo 'Title:'.$data['Count(`file_name`)'];
echo '<br>';

$sql = "Select Count(`file_name`) from `Documents` where `file_type` = 'Financial' and `ID` between 94 and 2703 and `loan_Id` != ''";
$results = $dblink->query($sql) or
		die("<h3> Something went wrong with: $sql<br>".$dblink->error);
$data = $results->fetch_array(MYSQLI_ASSOC);
echo 'Financial:'.$data['Count(`file_name`)'];
echo '<br>';

$sql = "Select Count(`file_name`) from `Documents` where `file_type` = 'Personal' and `ID` between 94 and 2703 and `loan_Id` != ''";
$results = $dblink->query($sql) or
		die("<h3> Something went wrong with: $sql<br>".$dblink->error);
$data = $results->fetch_array(MYSQLI_ASSOC);
echo 'Personal:'.$data['Count(`file_name`)'];
echo '<br>';

$sql = "Select Count(`file_name`) from `Documents` where `file_type` = 'Internal' and `ID` between 94 and 2703 and `loan_Id` != ''";
$results = $dblink->query($sql) or
		die("<h3> Something went wrong with: $sql<br>".$dblink->error);
$data = $results->fetch_array(MYSQLI_ASSOC);
echo 'Internal:'.$data['Count(`file_name`)'];
echo '<br>';

$sql = "Select Count(`file_name`) from `Documents` where `file_type` = 'Legal' and `ID` between 94 and 2703 and `loan_Id` != ''";
$results = $dblink->query($sql) or
		die("<h3> Something went wrong with: $sql<br>".$dblink->error);
$data = $results->fetch_array(MYSQLI_ASSOC);
echo 'Legal:'.$data['Count(`file_name`)'];
echo '<br>';

$sql = "Select Count(`file_name`) from `Documents` where `file_type` = 'Other' and `ID` between 94 and 2703 and `loan_Id` != ''";
$results = $dblink->query($sql) or
		die("<h3> Something went wrong with: $sql<br>".$dblink->error);
$data = $results->fetch_array(MYSQLI_ASSOC);
echo 'Other:'.$data['Count(`file_name`)'];
?>