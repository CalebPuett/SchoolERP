<?php
include("functions.php");
$dblink = db_connect("docstorage");
echo "<h3> Complete Loans:</h3>";
$sql = 'Select `loan_Id` From `Documents` where `ID` between 94 and 2703 and `loan_Id` != "" Group By `loan_Id` Having Count(Distinct `file_type`) = 8';
$results = $dblink->query($sql) or
		die("<h3> Something went wrong with: $sql<br>".$dblink->error);
if($results->num_rows<=0){
	echo "None";
}
else{
while($data = $results->fetch_array(MYSQLI_ASSOC)){
	echo ''.$data['loan_Id'].'<br>';
}
}
echo '<h3>Loan Numbers with no documents</h3>';
$sql = 'Select `loan_Id` From `Documents` where `ID` between 94 and 2703 and `loan_Id` != "" Group By `loan_Id` Having Count(Distinct `file_type`) = 0';
$results = $dblink->query($sql) or
		die("<h3> Something went wrong with: $sql<br>".$dblink->error);
if($results->num_rows<=0){
	echo "None";
}
else{
while($data = $results->fetch_array(MYSQLI_ASSOC)){
	echo ''.$data['loan_Id'].'<br>';
}
}
echo '<h3> Loan Numbers and their Missing Documents</h3>';
$sql = "SELECT\n"

    . "  DISTINCT(`loan_Id`),\n"

    . "  GROUP_CONCAT(DISTINCT missing_document ORDER BY missing_document) AS missing_documents\n"

    . "FROM (\n"

    . "  SELECT\n"

    . "    `loan_Id`,\n"

    . "    `file_type`,\n"

    . "    CASE\n"

    . "      WHEN COUNT(DISTINCT `file_type`) < 8 THEN `file_type`\n"

    . "      ELSE NULL\n"

    . "    END AS missing_document\n"

    . "  FROM `Documents`\n"

    . "  WHERE `file_type` IN ('credit', 'closing', 'title', 'financial', 'personal', 'internal', 'legal', 'other')\n"

    . "    and `loan_Id` != \"\"\n"

    . "    and `ID` between 94 and 2703\n"

    . "  GROUP BY `loan_Id`, `file_type`\n"

    . ") subquery\n"

    . "GROUP BY `loan_Id`\n"

    . "HAVING missing_documents IS NOT NULL;";
$results = $dblink->query($sql) or
		die("<h3> Something went wrong with: $sql<br>".$dblink->error);
while($data = $results->fetch_array(MYSQLI_ASSOC)){
	echo ''.$data['loan_Id'];
	if(!str_contains($data['missing_documents'],'Credit')){
		echo ' Credit';
	}
	if(!str_contains($data['missing_documents'],'Closing')){
		echo ' Closing';
	}
	
	
	if(!str_contains($data['missing_documents'],'Title')){
		echo ' Title';
	}
	
	if(!str_contains($data['missing_documents'],'Financial')){
		echo ' Financial';
	}
	
	if(!str_contains($data['missing_documents'],'Other')){
		echo ' Other';
	}
	
	if(!str_contains($data['missing_documents'],'Legal')){
		echo ' Legal';
	}
	
	if(!str_contains($data['missing_documents'],'Internal')){
		echo ' Internal';
	}
	
	if(!str_contains($data['missing_documents'],'Personal')){
		echo ' Personal';
	}
	
	echo '<br>';
	
}

?>