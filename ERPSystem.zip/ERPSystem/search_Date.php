<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Search By Date</title>
<!-- BOOTSTRAP STYLES-->
<link href="assets/css/bootstrap.css" rel="stylesheet" />
<!-- FONTAWESOME STYLES-->
<link href="assets/css/font-awesome.css" rel="stylesheet" />
   <!--CUSTOM BASIC STYLES-->
<link href="assets/css/basic.css" rel="stylesheet" />
<!--CUSTOM MAIN STYLES-->
<link href="assets/css/custom.css" rel="stylesheet" />
<!--[if lt IE 9]><script src="scripts/flashcanvas.js"></script><![endif]-->
<!-- JQUERY SCRIPTS -->
<script src="assets/js/jquery-1.10.2.js"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="assets/js/bootstrap.js"></script>


<style>
    .default {background-color:#E1E1E1;}
</style>
<script>
    function addFocus(div){
        document.getElementById(div).classList.remove("default");
    }
    function removeFocus(div){
        document.getElementById(div).classList.add("default");
    }
</script>
</head>
<body>
<?php
include ("functions.php");
$dblink = db_connect("docstorage");
echo '<div id="page-inner">';
echo '<h1 class="page-head-line">Enter the Date</h1>';
echo '<div class="panel-body">';
if(isset($_REQUEST['msg']) && ($_REQUEST['msg'] == "NotFound")){
	echo '<div class="alert alert-danger alert-dismissable">';
	echo '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>';
	echo 'Date was not found.</div>';
}
if(isset($_REQUEST['msg']) && ($_REQUEST['msg'] == "invalidDate")){
	echo '<div class="alert alert-warning alert-dismissable">';
	echo '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>';
	echo 'Date must only numbers and must be 8 digits (ymd)</div>';
}
if(isset($_REQUEST['msg']) && ($_REQUEST['msg'] == "dateError")){
	echo '<div class="alert alert-warning alert-dismissable">';
	echo '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>';
	echo 'Error date must be after 11/02/23.Please try again </div>';
}
if(!isset($_POST['submit'])){
	
	echo '<form method="post" action="">';
	echo '<div class="form-group">';
	echo '<label for="date" class="control-label">Date in format (20231102)</label>';
	echo '<input type="text" class="form-control" name="date">';
	echo '</div>';
	echo '<button name ="submit" type="submit" class = "btn btn-primary" value="submit">Search</button>';
	echo '</form>';
}

elseif(isset($_POST['submit']) && $_POST['submit'] == "submit"){
	$date = $_POST['date'];
	if(!preg_match('/[0-9]{8}/',$date)){
		redirect("https://ec2-18-188-192-136.us-east-2.compute.amazonaws.com/search_Date.php?msg=invalidDate");
	}
	$sql = "Select * from `Documents` where `date` like '$date%'";
	$results = $dblink->query($sql) or
		die("Something went wrong with: $sql<br>".$dblink->error);
	if($results->num_rows<=0){
		redirect("https://ec2-18-188-192-136.us-east-2.compute.amazonaws.com/search_Date.php?msg=NotFound");
	}
	else{
		echo "<h2>Results from Date: $date</h2>";
		echo '<table>';
		//$loan = $result->fetch_array(MYSQLI_ASSOC);
		echo '<th>File Name</th><th>File Type </th><th>&nbsp Upload Date </th><th>&nbsp Action </th>';
		while($data = $results->fetch_array(MYSQLI_ASSOC)){
			if($data['ID'] >= 15){ // due to content table not being on the same id as docs table
				echo "<tr>";
				echo '<td>'.$data['file_name'].'</td>';
				echo '<td>'.$data['file_type'].'</td>';
				$tmp = explode("-",$data['file_name']);
				$tmp1 = explode(".",$tmp[2]);
				$tmp2 = explode("_",$tmp1[0]);
				echo '<td>&nbsp'.$tmp2[0].'</td>';

					echo '<td><a href="https://ec2-18-188-192-136.us-east-2.compute.amazonaws.com/view_file.php?fid='.$data['ID'].'" target="_blank">View File</a></td>';
				}
			echo '</tr>';
		}
		echo '</table>';
	}
}
	
	
	
	
	