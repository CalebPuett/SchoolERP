<?php
include("functions.php");
$dblink = db_connect("docstorage");
$count = 0;
$sql = 'SELECT COUNT(DISTINCT `loan_Id`) FROM `Documents` where `ID` between 94 and 2703 and `loan_Id` != ""'; // Gets total number of 
$results = $dblink->query($sql) or
		die("<h3> Something went wrong with: $sql<br>".$dblink->error);
$data = $results->fetch_array(MYSQLI_ASSOC);
echo '<h3>Total Number of Unique Loan Numbers: '.$data['COUNT(DISTINCT `loan_Id`)'].'</h3>';
// Gets total number of  unique loan ids

$sql = 'Select Sum(`file_Size`) from `Doc_Size` where `file_id` between 94 and 2703';
$results = $dblink->query($sql) or
		die("<h3> Something went wrong with: $sql<br>".$dblink->error);
$data = $results->fetch_array(MYSQLI_ASSOC);
echo '<h3>Total Size of All Documents: '.round($data['Sum(`file_Size`)']).' bytes</h3>';
// gets Total size of all documents

$sql = 'Select Avg(`file_Size`) from `Doc_Size` where `file_id` between 94 and 2703';
$results = $dblink->query($sql) or
		die("<h3> Something went wrong with: $sql<br>".$dblink->error);
$data = $results->fetch_array(MYSQLI_ASSOC);
$average_docSize = round($data['Avg(`file_Size`)']);
echo '<h3>Average Size of All Documents: '.$average_docSize.' bytes </h3>';
//gets average size of all documents



$sql = 'Select COUNT(`loan_Id`) FROM `Documents` where `ID` between 94 and 2703 and `loan_Id` != ""'; 
$results = $dblink->query($sql) or
		die("<h3> Something went wrong with: $sql<br>".$dblink->error);
$data = $results->fetch_array(MYSQLI_ASSOC);
echo '<h3>Total Number of Documents Recived: '.$data['COUNT(`loan_Id`)'].'</h3>';
// total ammount of documments

$sql = 'Select Avg(document_count) as average_documents_per_loan  
		From(
			Select `loan_Id`, Count(*) as document_count
			From `Documents`
			Where `ID` between 94 and 2703 and `loan_Id` != "" 
			Group By `loan_Id`
		)as loan_document_counts'; // average amount of documents per loan_id
$results = $dblink->query($sql) or
		die("<h3> Something went wrong with: $sql<br>".$dblink->error);
$data = $results->fetch_array(MYSQLI_ASSOC);
$average_docPerLoan = round($data['average_documents_per_loan']);
echo '<table>';
echo '<h3>Average Number of Documents Across All Loans: '.$average_docPerLoan.'</h3>';
echo '<th>Unique Loan Number</th><th> Total Documents</th> <th> Average Size</th>';
$sql = 'SELECT DISTINCT `loan_Id` FROM `Documents` where `ID` between 94 and 2703 and `loan_Id` != ""';
$results = $dblink->query($sql) or
		die("<h3> Something went wrong with: $sql<br>".$dblink->error);
while($data = $results->fetch_array(MYSQLI_ASSOC)){
	echo "<tr>";
	echo '<td>'.$data['loan_Id'].'</td>';
	$total = getLoanTotalDoc($data['loan_Id'],$dblink);
	if($total > $average_docPerLoan){
		echo '<td>'.$total.' Above Average</td>';
	}
	else if($total == $average_docPerLoan){
		echo '<td>'.$total.' Average</td>';
}
	else{
		echo '<td>'.$total.' Below Average</td>';
	}
	$average = round(getAverageSizeForLoanID($data['loan_Id'],$dblink));
	if($average>$average_docSize){
		echo '<td>'.$average.' bytes. Above Average Size</td>';
	}
	else if($average == $average_docSize){
		echo '<td>'.$average.' bytes. Average Size</td>';
	}
	else{
		echo '<td>'.$average.' bytes. Below Average Size</td>';
	}
}
?>
