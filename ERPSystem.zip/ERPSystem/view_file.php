<?php
include("functions.php");
$dblink = db_connect("docstorage");
$fid = $_REQUEST['fid'];
$sql = "Select `file_content` from `Document_Content` where `file_id` = '$fid'";
$results = $dblink->query($sql) or
		die("<h3> Something went wrong with: $sql<br>".$dblink->error);
$data = $results->fetch_array(MYSQLI_ASSOC);
header('Content-Type: application/pdf');
header('Content-Length: '.strlen($data['file_content']));
echo $data['file_content'];
?>
