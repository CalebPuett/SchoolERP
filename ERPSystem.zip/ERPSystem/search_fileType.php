<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Search By File Type</title>
<!-- BOOTSTRAP STYLES-->
<link href="assets/css/bootstrap.css" rel="stylesheet" />
<!-- FONTAWESOME STYLES-->
<link href="assets/css/font-awesome.css" rel="stylesheet" />
   <!--CUSTOM BASIC STYLES-->
<link href="assets/css/basic.css" rel="stylesheet" />
<!--CUSTOM MAIN STYLES-->
<link href="assets/css/custom.css" rel="stylesheet" />
<!--[if lt IE 9]><script src="scripts/flashcanvas.js"></script><![endif]-->
<!-- JQUERY SCRIPTS -->
<script src="assets/js/jquery-1.10.2.js"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="assets/js/bootstrap.js"></script>


<style>
    .default {background-color:#E1E1E1;}
</style>
<script>
    function addFocus(div){
        document.getElementById(div).classList.remove("default");
    }
    function removeFocus(div){
        document.getElementById(div).classList.add("default");
    }
</script>
</head>
<body>
<?php
include ("functions.php");
$dblink = db_connect('docstorage');
echo '<div id="page-inner">';
echo '<h1 class="page-head-line">Enter the File Type</h1>';
echo '<div class="panel-body">';
if(isset($_REQUEST['msg']) && ($_REQUEST['msg'] == "NotFound")){
	echo '<div class="alert alert-danger alert-dismissable">';
	echo '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>';
	echo 'Loan Number was not found.</div>';
}
if(isset($_REQUEST['msg']) && ($_REQUEST['msg'] == "invalidLoanNum")){
	echo '<div class="alert alert-warning alert-dismissable">';
	echo '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>';
	echo 'Loan Number must only numbers and must be 8 digits </div>';
}
if(!isset($_POST['submit'])){
	
echo '<form method="post" action="">';
echo '<div class="form-group">';
echo '<label for="docType" class="control-label">Document Type</label>';
echo '<select class="form-control" name="docType">';
$sql = "SELECT DISTINCT `file_type` FROM `Documents` Where `file_type` != ''";
$results = $dblink->query($sql) or
	die("Something went wrong with: $sql<br>".$dblink->error);
	while($data=$results->fetch_array(MYSQLI_ASSOC)){
		echo '<option value="'.$data['file_type'].'">'.$data['file_type'].'</option>';
	}
	echo '</select>';
	echo '</div>';
	echo '<button name ="submit" type="submit" class = "btn btn-primary" value="submit">Search</button>';
	echo "</form>";
}
elseif(isset($_POST['submit']) && $_POST['submit'] == "submit"){
 	$docType = $_POST['docType'];
	$sql = "SELECT * FROM `Documents` WHERE `file_type` = '$docType'";
	$results = $dblink->query($sql) or
		die("Something went wrong with: $sql<br>".$dblink->error);
	if($results->num_rows<=0){
		redirect("https://ec2-18-188-192-136.us-east-2.compute.amazonaws.com/search_loanNumber.php?msg=NotFound");
	}
	else{
		echo "<h2>Results from File Type: $docType</h2>";
		echo '<table>';
		//$loan = $result->fetch_array(MYSQLI_ASSOC);
		echo '<th>File Name</th><th>File Type </th><th>&nbsp Upload Date </th><th>&nbsp Action </th>';
		while($data = $results->fetch_array(MYSQLI_ASSOC)){
			if($data['ID'] >= 15){ // due to content table not being on the same id as docs table
				echo "<tr>";
				echo '<td>'.$data['file_name'].'</td>';
				echo '<td>'.$data['file_type'].'</td>';
				$tmp = explode("-",$data['file_name']);
				$tmp1 = explode(".",$tmp[2]);
				$tmp2 = explode("_",$tmp1[0]);
				echo '<td>&nbsp'.$tmp2[0].'</td>';

					echo '<td><a href="https://ec2-18-188-192-136.us-east-2.compute.amazonaws.com/view_file.php?fid='.$data['ID'].'" target="_blank">View File</a></td>';
				}
			echo '</tr>';
		}
		echo '</table>';
}
	
	
}
	
	
	
echo '</div>';
echo '</div>';
?>
</body>
</html>
